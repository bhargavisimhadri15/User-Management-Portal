import React, { useState, useMemo, useEffect } from "react";
import "./App.css";

// 1. CONFIGURATION SCHEMA (Extensibility Source of Truth)
// To add "Address" or "DOB", just add an object here.
const USER_FIELDS = [
  { name: "firstName", label: "First Name", type: "text", required: true },
  { name: "lastName", label: "Last Name", type: "text", required: true },
  { name: "phone", label: "Phone Number", type: "tel", required: true },
  { name: "email", label: "Email Address", type: "email", required: true },
];

const App = () => {
  const [users, setUsers] = useState([]);
  const [formData, setFormData] = useState({});
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState("");
  const [isDark, setIsDark] = useState(false);

  // Theme Toggle Logic
  const toggleTheme = () => {
    setIsDark(!isDark);
    document.documentElement.setAttribute("data-theme", !isDark ? "dark" : "light");
  };

  // CRUD Operations
  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingId) {
      setUsers(users.map(u => u.id === editingId ? { ...formData, id: u.id } : u));
      setEditingId(null);
    } else {
      setUsers([...users, { ...formData, id: Date.now() }]);
    }
    setFormData({});
  };

  const deleteUser = (id) => {
    if (window.confirm("Are you sure?")) setUsers(users.filter(u => u.id !== id));
  };

  const startEdit = (user) => {
    setEditingId(user.id);
    setFormData(user);
  };

  // Search Logic (Works on all schema fields automatically)
  const filteredUsers = useMemo(() => {
    return users.filter(u =>
      Object.values(u).some(val => String(val).toLowerCase().includes(search.toLowerCase()))
    );
  }, [users, search]);

  return (
    <div className="app-container">
      <header className="main-header">
        <h1>User Management Portal</h1>
        <div className="header-actions">
          <button onClick={toggleTheme} className="theme-btn">
            {isDark ? "☀️ Light" : "🌙 Dark"}
          </button>
          <input 
            type="text" 
            placeholder="Global search..." 
            className="search-input"
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </header>

      <div className="content-grid">
        {/* Dynamic Form */}
        <section className="card form-card">
          <h2>{editingId ? "Edit User" : "Add New User"}</h2>
          <form onSubmit={handleSubmit}>
            {USER_FIELDS.map(field => (
              <div key={field.name} className="form-group">
                <label>{field.label}</label>
                <input
                  type={field.type}
                  required={field.required}
                  value={formData[field.name] || ""}
                  onChange={(e) => setFormData({...formData, [field.name]: e.target.value})}
                />
              </div>
            ))}
            <button type="submit" className="btn-save">
              {editingId ? "Update Record" : "Create Record"}
            </button>
            {editingId && (
              <button onClick={() => {setEditingId(null); setFormData({});}} className="btn-cancel">Cancel</button>
            )}
          </form>
        </section>

        {/* Dynamic Table */}
        <section className="card table-card">
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  {USER_FIELDS.map(f => <th key={f.name}>{f.label}</th>)}
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map(user => (
                  <tr key={user.id}>
                    {USER_FIELDS.map(f => <td key={f.name}>{user[f.name]}</td>)}
                    <td>
                      <button onClick={() => startEdit(user)} className="edit-btn">Edit</button>
                      <button onClick={() => deleteUser(user.id)} className="delete-btn">Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
};

export default App;
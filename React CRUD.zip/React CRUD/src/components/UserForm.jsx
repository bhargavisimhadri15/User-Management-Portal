import React, { useState, useEffect } from 'react';
import { USER_SCHEMA } from '../userSchema'; // Correct relative path

const UserForm = ({ onSubmit, initialData, buttonText }) => {
  const [formData, setFormData] = useState({});

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    } else {
      setFormData({});
    }
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
    setFormData({});
  };

  return (
    <form onSubmit={handleSubmit}>
      {USER_SCHEMA.map((field) => (
        <div key={field.name} className="form-group">
          <label>{field.label}</label>
          <input
            name={field.name}
            type={field.type}
            required={field.required}
            value={formData[field.name] || ''}
            onChange={handleChange}
            placeholder={`Enter ${field.label}`}
          />
        </div>
      ))}
      <button type="submit" className="btn-primary">{buttonText}</button>
    </form>
  );
};

export default UserForm;
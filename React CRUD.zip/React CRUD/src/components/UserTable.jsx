import React from 'react';
import { USER_FIELDS } from '../config/userSchema';

const UserTable = ({ users, onDeleteUser }) => {
  return (
    <div className="table-container">
      <table>
        <thead>
          <tr>
            {/* Dynamically create headers from schema */}
            {USER_FIELDS.map((field) => (
              <th key={field.name}>{field.label}</th>
            ))}
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.length > 0 ? (
            users.map((user) => (
              <tr key={user.id}>
                {/* Dynamically fill cells based on schema keys */}
                {USER_FIELDS.map((field) => (
                  <td key={field.name}>
                    {field.type === 'date' && user[field.name]
                      ? new Date(user[field.name]).toLocaleDateString()
                      : user[field.name]}
                  </td>
                ))}
                <td>
                  <button 
                    className="btn-delete" 
                    onClick={() => onDeleteUser(user.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={USER_FIELDS.length + 1} className="no-data">
                No users found.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default UserTable;
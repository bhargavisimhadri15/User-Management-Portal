import { useState, useEffect } from 'react';

export const useUsers = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  // READ
  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(res => res.json())
      .then(data => {
        setUsers(data.map(u => ({ ...u, phone: '1234567890' }))); // Normalizing mock data
        setLoading(false);
      });
  }, []);

  // CREATE
  const addUser = (user) => setUsers([...users, { ...user, id: Date.now() }]);

  // UPDATE
  const updateUser = (id, updatedUser) => {
    setUsers(users.map(u => u.id === id ? { ...updatedUser, id } : u));
  };

  // DELETE
  const deleteUser = (id) => setUsers(users.filter(u => u.id !== id));

  return { users, loading, addUser, updateUser, deleteUser };
};